"""Private bot.txt reader/writer. Keep bot.txt outside static/."""
from pathlib import Path
import os, tempfile

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = Path(os.environ.get("BOT_CONFIG_PATH", str(ROOT / "bot.txt"))).resolve()
DEFAULTS = {
    "UID": "",
    "PASSWORD": "",
    "NICK": "TANBIR TCP",
    "REGION": "BD",
    "AUTOSTART": "false",
    "LOGIN_MODE": "uid_password",
}

def read_config():
    data = DEFAULTS.copy()
    try:
        for line in CONFIG_PATH.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            if key.strip() in data:
                data[key.strip()] = value.strip()
    except FileNotFoundError:
        write_config(data)
    return data

def write_config(updates):
    data = read_config() if CONFIG_PATH.exists() else DEFAULTS.copy()
    for key, value in updates.items():
        if key in data and value is not None:
            data[key] = str(value)
    text = "# Private bot configuration; do not put this file in a public/static directory.\n"
    text += "".join(f"{k}={data[k]}\n" for k in DEFAULTS)
    fd, tmp = tempfile.mkstemp(prefix="bot.", suffix=".tmp", dir=str(ROOT))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp, CONFIG_PATH)
        try: os.chmod(CONFIG_PATH, 0o600)
        except OSError: pass
    finally:
        if os.path.exists(tmp): os.unlink(tmp)
    return data

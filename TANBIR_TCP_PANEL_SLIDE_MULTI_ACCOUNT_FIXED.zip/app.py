import os, sys, time, threading, subprocess, secrets, socket
from pathlib import Path
from collections import deque
from functools import wraps
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from config_store import read_config, write_config

ROOT = Path(__file__).resolve().parent
app = Flask(__name__, template_folder=str(ROOT / "templates"), static_folder=str(ROOT / "static"))
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_urlsafe(32)
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")
# Defaults let the panel work even if the host dashboard has no custom variables.
# Override these values in the host environment before public production use.
PANEL_USER = os.environ.get("PANEL_USER", "tanbirtcp")
PANEL_PASSWORD = os.environ.get("PANEL_PASSWORD", "tanbirtcp")
ADMIN_USER = os.environ.get("ADMIN_USER", "tanbir10")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "tanbir10")
# The web panel starts independently. The bot only starts after an explicit Start click
# unless AUTOSTART=true is deliberately enabled in bot.txt.
bot_process = None
started_at = 0
log_lines = deque(maxlen=1500)
lock = threading.RLock()
# Extra account processes use bot1.txt, bot2.txt, ...
extra_processes = {}
extra_started = {}
extra_logs = {}


def is_logged_in():
    return bool(session.get("panel_user"))

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not is_logged_in():
            return jsonify(ok=False, error="Please log in again"), 401
        return fn(*args, **kwargs)
    return wrapper

def running():
    return bot_process is not None and bot_process.poll() is None

def start_bot():
    global bot_process, started_at
    cfg = read_config()
    if not cfg.get("UID") or not cfg.get("PASSWORD"):
        return False, "Set UID and password in Bot Control first."
    with lock:
        if running():
            return True, "Bot is already running."
        try:
            bot_process = subprocess.Popen(
                [sys.executable, str(ROOT / "main.py")], cwd=str(ROOT),
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                bufsize=1
            )
            started_at = time.time()
            def collect(proc):
                try:
                    for line in proc.stdout:
                        log_lines.append({"t": time.strftime("%H:%M:%S"), "src":"bot", "msg":line.rstrip()[:1000]})
                except Exception:
                    pass
            threading.Thread(target=collect, args=(bot_process,), daemon=True).start()
            return True, "Bot process started."
        except Exception as exc:
            return False, "Could not start bot: " + str(exc)

def stop_bot():
    global bot_process
    with lock:
        if not running():
            return True, "Bot is already stopped."
        bot_process.terminate()
        try: bot_process.wait(timeout=8)
        except subprocess.TimeoutExpired: bot_process.kill()
        return True, "Bot stopped."

def account_path(account_id):
    if account_id == 0:
        return ROOT / "bot.txt"
    return ROOT / f"bot{account_id}.txt"

def read_account(account_id):
    from config_store import DEFAULTS
    path = account_path(account_id)
    data = DEFAULTS.copy()
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            line=line.strip()
            if line and not line.startswith("#") and "=" in line:
                k,v=line.split("=",1)
                if k.strip() in data: data[k.strip()]=v.strip()
    except FileNotFoundError:
        pass
    return data

def write_account(account_id, updates):
    from config_store import DEFAULTS
    path=account_path(account_id); data=read_account(account_id)
    for k,v in updates.items():
        if k in DEFAULTS and v is not None: data[k]=str(v)
    path.write_text("# Private account config\n"+"".join(f"{k}={data[k]}\n" for k in DEFAULTS), encoding="utf-8")
    try: os.chmod(path, 0o600)
    except OSError: pass
    return data

def extra_running(account_id):
    proc=extra_processes.get(account_id)
    return proc is not None and proc.poll() is None

def start_extra(account_id):
    cfg=read_account(account_id)
    if not cfg.get("UID") or not cfg.get("PASSWORD"):
        return False, "Enter UID and password and save first."
    if extra_running(account_id): return True, "This account is already running."
    env=os.environ.copy(); env["BOT_CONFIG_PATH"]=str(account_path(account_id))
    try:
        proc=subprocess.Popen([sys.executable, str(ROOT/"main.py")], cwd=str(ROOT), env=env,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        extra_processes[account_id]=proc; extra_started[account_id]=time.time()
        extra_logs.setdefault(account_id, deque(maxlen=500))
        def collect_extra():
            try:
                for line in proc.stdout:
                    extra_logs[account_id].append({"t":time.strftime("%H:%M:%S"),"msg":line.rstrip()[:1000]})
            except Exception: pass
        threading.Thread(target=collect_extra, daemon=True).start()
        return True, f"Account {account_id+1} process started."
    except Exception as exc: return False, str(exc)

def stop_extra(account_id):
    proc=extra_processes.get(account_id)
    if proc is None or proc.poll() is not None: return True, "This account is already stopped."
    proc.terminate()
    try: proc.wait(timeout=8)
    except subprocess.TimeoutExpired: proc.kill()
    return True, f"Account {account_id+1} stopped."

@app.get("/api/accounts")
@login_required
def api_accounts():
    accounts=[]
    for aid in range(0,100):
        path=account_path(aid)
        if aid == 0 or path.exists():
            c=read_account(aid)
            accounts.append({"id":aid,"file":path.name,"uid":c.get("UID",""),"nick":c.get("NICK","TANBIR TCP"),"region":c.get("REGION","BD"),"has_password":bool(c.get("PASSWORD")),"running":running() if aid==0 else extra_running(aid)})
    return jsonify(ok=True,accounts=accounts)

@app.post("/api/accounts")
@login_required
def api_add_account():
    data=request.get_json(silent=True) or {}
    uid=str(data.get("uid","")).strip(); password=str(data.get("password","")).strip()
    if not uid or not password: return jsonify(ok=False,error="UID and password are required."),400
    if len(uid)>40 or len(password)>512: return jsonify(ok=False,error="UID/password is too long."),400
    aid=next((i for i in range(1,100) if not account_path(i).exists()),None)
    if aid is None: return jsonify(ok=False,error="Account limit reached (99 extra accounts)."),400
    write_account(aid,{"UID":uid,"PASSWORD":password,"NICK":str(data.get("nick") or "TANBIR TCP")[:40],"REGION":str(data.get("region") or "BD"),"AUTOSTART":"false","LOGIN_MODE":"uid_password"})
    return jsonify(ok=True,message=f"Saved as {account_path(aid).name}.",id=aid,file=account_path(aid).name)

@app.post("/api/accounts/<int:account_id>/start")
@login_required
def api_start_account(account_id):
    if account_id==0: ok,msg=start_bot()
    elif 1<=account_id<100: ok,msg=start_extra(account_id)
    else: return jsonify(ok=False,error="Invalid account ID."),400
    return jsonify(ok=ok,message=msg)

@app.post("/api/accounts/<int:account_id>/stop")
@login_required
def api_stop_account(account_id):
    if account_id==0: ok,msg=stop_bot()
    elif 1<=account_id<100: ok,msg=stop_extra(account_id)
    else: return jsonify(ok=False,error="Invalid account ID."),400
    return jsonify(ok=ok,message=msg)

@app.delete("/api/accounts/<int:account_id>")
@login_required
def api_delete_account(account_id):
    if account_id==0: return jsonify(ok=False,error="The primary bot.txt account cannot be deleted."),400
    if not 1<=account_id<100: return jsonify(ok=False,error="Invalid account ID."),400
    stop_extra(account_id)
    try: account_path(account_id).unlink()
    except FileNotFoundError: return jsonify(ok=False,error="Account not found."),404
    return jsonify(ok=True,message=f"Deleted {account_path(account_id).name}.")

@app.route("/")
def home():
    return redirect(url_for("panel") if is_logged_in() else url_for("login"))

@app.route("/login")
def login():
    return render_template("login.html")

@app.route("/panel")
def panel():
    if not is_logged_in(): return redirect(url_for("login"))
    return render_template("pro.html", role=session.get("panel_role", "user"), user=session.get("panel_user", "tanbirtcp"))

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.post("/api/login")
def api_login():
    data = request.get_json(silent=True) or {}
    user, password = str(data.get("username","")), str(data.get("password",""))
    accounts = {
        PANEL_USER: (PANEL_PASSWORD, "user"),
        ADMIN_USER: (ADMIN_PASSWORD, "admin"),
    }
    account = accounts.get(user)
    if account and secrets.compare_digest(password, account[0]):
        session["panel_user"] = user
        session["panel_role"] = account[1]
        return jsonify(status="success", role=account[1])
    return jsonify(status="error", message="Invalid username or password.")

@app.post("/api/quick")
def quick_login_disabled():
    return jsonify(status="error", message="Quick login is disabled. Use your secure panel username/password.")

@app.get("/api/status")
@login_required
def api_status():
    cfg=read_config()
    return jsonify(ok=True, running=running(), uptime=int(time.time()-started_at) if running() else 0,
                   commands=300, uid=cfg["UID"], nick=cfg["NICK"], region=cfg["REGION"],
                   mode=cfg["LOGIN_MODE"])

@app.get("/api/config")
@login_required
def api_get_config():
    c=read_config()
    return jsonify(ok=True, uid=c["UID"], nick=c["NICK"], region=c["REGION"],
                   autostart=c["AUTOSTART"].lower()=="true", has_password=bool(c["PASSWORD"]))

@app.post("/api/config")
@login_required
def api_set_config():
    data=request.get_json(silent=True) or {}
    updates={}
    for field,key in [("uid","UID"),("nick","NICK"),("region","REGION"),("autostart","AUTOSTART")]:
        if field in data:
            val=data[field]
            if field=="uid" and len(str(val))>40: return jsonify(ok=False,error="UID is too long")
            if field=="nick" and len(str(val))>40: return jsonify(ok=False,error="Nickname is too long")
            if field=="region" and str(val) not in {"BD","IND","PK","ID","SG","ME","VN","TW","CIS","TH","EU","US","SAC"}:
                return jsonify(ok=False,error="Unsupported region")
            updates[key] = str(val).lower() if field=="autostart" else str(val).strip()
    if data.get("password"):
        if len(str(data["password"]))>512: return jsonify(ok=False,error="Password is too long")
        updates["PASSWORD"]=str(data["password"])
    cfg=write_config(updates)
    if data.get("start"):
        ok,msg=start_bot()
        return jsonify(ok=ok,message=msg)
    return jsonify(ok=True,message="Saved to bot.txt.")

@app.post("/api/bot/<action>")
@login_required
def api_bot_action(action):
    if action in ("start","restart"):
        if action=="restart": stop_bot()
        ok,msg=start_bot()
    elif action=="stop": ok,msg=stop_bot()
    else: return jsonify(ok=False,error="Unknown action")
    return jsonify(ok=ok,message=msg)

@app.post("/api/logs/clear")
@login_required
def api_clear_logs():
    log_lines.clear()
    return jsonify(ok=True, message="Logs cleared.")

@app.get("/api/logs")
@login_required
def api_logs():
    try: since=max(0,int(request.args.get("since",0)))
    except ValueError: since=0
    logs=list(log_lines)
    return jsonify(ok=True,logs=logs[since:],last=len(logs))

@app.post("/api/mode")
@login_required
def api_mode():
    data=request.get_json(silent=True) or {}
    mode=data.get("mode")
    # Phone/PC are UI preferences; credentials still use the UID/password flow.
    if mode not in ("uid_password", "token", "phone", "pc"):
        return jsonify(ok=False,error="Unsupported mode")
    write_config({"LOGIN_MODE": mode})
    return jsonify(ok=True,message="Login preference saved for the next start.")

@app.get("/api/commands")
@login_required
def api_commands():
    # A small accurate starter catalog; expand this list to match implemented bot commands.
    raw = [
      ("/help", "Show the help menu", "BOT"), ("/ping", "Check response", "BOT"),
      ("/uptime", "Show bot uptime", "BOT"), ("/botinfo", "Show bot information", "BOT"),
      ("/time bd", "Bangladesh time", "TIME"), ("/time ind", "India time", "TIME"),
      ("/time usa", "USA time", "TIME"), ("/date", "Show current date", "TIME"),
      ("/love", "Fun compatibility result", "FUN"), ("/luck", "Random luck result", "FUN"),
      ("/joke", "Tell a joke", "FUN"), ("/dhadha", "Ask a riddle", "FUN"),
      ("/roast", "Playful roast", "FUN"), ("/calc", "Calculate an expression", "TOOLS"),
      ("/bold", "Format text in bold style", "TEXT"), ("/b64", "Base64 text utility", "TEXT"),
      ("/weather", "Weather lookup if configured", "INFO"), ("/info", "Show available info", "INFO"),
      ("/restart", "Restart bot (owner only)", "ADMIN"), ("/admin", "Show admin information", "ADMIN")
    ]
    commands = [{"cmd":c,"desc":d,"cat":cat,"page":(i//4)+1} for i,(c,d,cat) in enumerate(raw)]
    return jsonify(ok=True, commands=commands)

@app.get("/api/zones")
@login_required
def api_zones():
    zones = [
      {"code":"bd","label":"Bangladesh","tz":"Asia/Dhaka"},
      {"code":"in","label":"India","tz":"Asia/Kolkata"},
      {"code":"pk","label":"Pakistan","tz":"Asia/Karachi"},
      {"code":"sg","label":"Singapore","tz":"Asia/Singapore"},
      {"code":"uk","label":"United Kingdom","tz":"Europe/London"},
      {"code":"us","label":"United States (New York)","tz":"America/New_York"},
      {"code":"jp","label":"Japan","tz":"Asia/Tokyo"},
      {"code":"sa","label":"Saudi Arabia","tz":"Asia/Riyadh"}
    ]
    return jsonify(ok=True, zones=zones)

@app.post("/api/password")
@login_required
def api_change_password():
    data=request.get_json(silent=True) or {}
    current_password = ADMIN_PASSWORD if session.get("panel_role") == "admin" else PANEL_PASSWORD
    if data.get("old") != current_password:
        return jsonify(ok=False,error="Current panel password is incorrect."), 400
    new_password=str(data.get("new", ""))
    if len(new_password) < 12:
        return jsonify(ok=False,error="New password must be at least 12 characters."), 400
    return jsonify(ok=False,error="For security, update PANEL_PASSWORD in hosting environment variables and restart.")

@app.get("/api/users")
@login_required
def api_users():
    return jsonify(ok=True,users=[{"name":PANEL_USER,"role":"user"},{"name":ADMIN_USER,"role":"admin"}])

@app.post("/api/users")
@login_required
def api_add_user():
    return jsonify(ok=False,error="Additional panel users are not enabled; use the configured admin login."), 400

@app.delete("/api/users")
@login_required
def api_delete_user():
    return jsonify(ok=False,error="The configured admin account cannot be deleted here."), 400

@app.get("/health")
def health():
    return jsonify(status="ok")

if __name__ == "__main__":
    cfg = read_config()
    port = int(os.environ.get("PORT", "8000"))
    # Start only the website by default; the bot is started from the authenticated panel.
    if cfg.get("AUTOSTART", "false").lower() == "true":
        threading.Thread(target=start_bot, daemon=True).start()
    try:
        host_ip = socket.gethostbyname(socket.gethostname())
    except OSError:
        host_ip = "127.0.0.1"
    print("\n[TANBIR TCP] Web panel is starting (bot does not auto-run by default).", flush=True)
    print(f"[TANBIR TCP] Local website: http://127.0.0.1:{port}", flush=True)
    if host_ip and not host_ip.startswith("127."):
        print(f"[TANBIR TCP] Network website: http://{host_ip}:{port}", flush=True)
    print("[TANBIR TCP] For a public hosted URL, deploy this project and use the URL shown by your hosting provider.", flush=True)
    print("[TANBIR TCP] Panel login defaults are active unless overridden by hosting environment variables.", flush=True)
    app.run(host="0.0.0.0", port=port, debug=False)
